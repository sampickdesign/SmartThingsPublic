# Generic-Video-Camera
I no longer support ST or any of the code I have written for that platform. Check out https://hubitat.com for my latest project and team I'm working on that is better than ST and is all local.
